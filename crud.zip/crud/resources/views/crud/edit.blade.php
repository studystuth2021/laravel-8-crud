@extends('page.layout')

@section('title','Edit Page')

@section('content')
<div class="row">
@include('page.message')
<form action="{{ route('crud.update',$post->id) }}" method="POST">
@method('PUT')
@csrf
<div class="col-lg-6 col-md-6 col-sm-12">
<div class="mb-3">
<label class="form-label">Name</label>
<input type="text" name="name" class="form-control" value="{{ $post->name }}">
</div>
</div>
<div class="col-lg-6 col-md-6 col-sm-12">
<div class="mb-3">
<label class="form-label">City Name</label>
<input type="text" name="city" class="form-control" value="{{ $post->city }}">
</div>
</div>
<div class="col-lg-12 col-md-12 col-sm-12">
<button type="submit" class="btn btn-sm btn-success">Submit</button>
<a href="{{ route('crud.index') }}" class="btn btn-warning btn-sm">Go Back</a>
</div>
</form>
</div>
@endsection