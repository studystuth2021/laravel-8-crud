@extends('page.layout')

@section('title','View Page')

@section('content')
<div class="row">
<div class="col-md-12 col-lg-12 col-sm-12">
<table class="table table-striped table-bordered">
<tr>
<th>Name</th>
<td>{{ $post->name }}</td>
</tr>
<tr>
<th>City Name</th>
<td>{{ $post->city }}</td>
</tr>
<tr>
<th>Actions</th>
<td>
<a href="{{ route('crud.edit',$post->id) }}" class="btn btn-success btn-sm">Edit Record</a>
<a href="{{ route('crud.index') }}" class="btn btn-info btn-sm">Go Back</a>
<a href="{{ route('crud.destroy',$post->id) }}" class="btn btn-danger btn-sm"
onclick="event.preventDefault();document.getElementById('delete-form').submit();">
Delete Record
</a>
<form action="{{ route('crud.destroy',$post->id) }}" method="POST" id="delete-form">
@csrf
@method('DELETE')
</form>
</td>
</tr>
</table>
</div>
</div>
@endsection