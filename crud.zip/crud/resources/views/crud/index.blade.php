@extends('page.layout')

@section('title','Index Page')

@section('content')
<div class="row">

@include('page.message')
<div class="col-md-12 col-lg-12 col-sm-12">
<div class="text-end mrb-10">
<a href="{{ route('crud.create') }}" class="btn btn-primary btn-sm">Add Record</a>
</div>
</div>

<div class="col-md-12 col-lg-12 col-sm-12">
<table class="table table-striped table-bordered">
<thead>
<tr>
<th>#</th>
<th>Name</th>
<th>City</th>
<th>Actions</th>
</tr>
</thead>
<tbody>
@php
$no = 1;
@endphp
@foreach($posts as $item)
<tr>
<td>{{ $no++ }}</td>
<td>{{ $item->name }}</td>
<td>{{ $item->city }}</td>
<td>
<a href="{{ route('crud.edit',$item->id) }}" class="btn btn-success btn-sm">Edit Record</a>
<a href="{{ route('crud.show',$item->id) }}" class="btn btn-info btn-sm">View Record</a>
<a href="{{ route('crud.destroy',$item->id) }}" class="btn btn-danger btn-sm"
onclick="event.preventDefault();document.getElementById('delete-form').submit();">
Delete Record
</a>
<form action="{{ route('crud.destroy',$item->id) }}" method="POST" id="delete-form">
@csrf
@method('DELETE')
</form>
</td>
</tr>
@endforeach
</tbody>
</table>
</div>

</div>
@endsection