@extends('page.layout')

@section('title','Create Page')

@section('content')
<div class="row">
@include('page.message')
<form action="{{ route('crud.store') }}" method="POST" id="delete-form">
@csrf
<div class="col-lg-6 col-md-6 col-sm-12">
<div class="mb-3">
<label class="form-label">Name</label>
<input type="text" name="name" class="form-control" value="{{ old('name') }}">
</div>
</div>
<div class="col-lg-6 col-md-6 col-sm-12">
<div class="mb-3">
<label class="form-label">City Name</label>
<input type="text" name="city" class="form-control" value="{{ old('city') }}">
</div>
</div>
<div class="col-lg-12 col-md-12 col-sm-12">
<button type="submit" class="btn btn-sm btn-success">Submit</button>
<a href="{{ route('crud.index') }}" class="btn btn-warning btn-sm">Go Back</a>
</div>
</form>
</div>
@endsection