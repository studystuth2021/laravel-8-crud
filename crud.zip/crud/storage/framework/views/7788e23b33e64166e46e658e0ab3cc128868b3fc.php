

<?php $__env->startSection('title','Create Page'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
<?php echo $__env->make('page.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<form action="<?php echo e(route('crud.store')); ?>" method="POST" id="delete-form">
<?php echo csrf_field(); ?>
<div class="col-lg-6 col-md-6 col-sm-12">
<div class="mb-3">
<label class="form-label">Name</label>
<input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>">
</div>
</div>
<div class="col-lg-6 col-md-6 col-sm-12">
<div class="mb-3">
<label class="form-label">City Name</label>
<input type="text" name="city" class="form-control" value="<?php echo e(old('city')); ?>">
</div>
</div>
<div class="col-lg-12 col-md-12 col-sm-12">
<button type="submit" class="btn btn-sm btn-success">Submit</button>
<a href="<?php echo e(route('crud.index')); ?>" class="btn btn-warning btn-sm">Go Back</a>
</div>
</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('page.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\91959\Desktop\crud\resources\views/crud/create.blade.php ENDPATH**/ ?>