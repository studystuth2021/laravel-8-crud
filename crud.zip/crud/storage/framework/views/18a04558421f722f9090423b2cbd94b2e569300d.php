

<?php $__env->startSection('title','Index Page'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">

<?php echo $__env->make('page.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="col-md-12 col-lg-12 col-sm-12">
<div class="text-end mrb-10">
<a href="<?php echo e(route('crud.create')); ?>" class="btn btn-primary btn-sm">Add Record</a>
</div>
</div>

<div class="col-md-12 col-lg-12 col-sm-12">
<table class="table table-striped table-bordered">
<thead>
<tr>
<th>#</th>
<th>Name</th>
<th>City</th>
<th>Actions</th>
</tr>
</thead>
<tbody>
<?php
$no = 1;
?>
<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($no++); ?></td>
<td><?php echo e($item->name); ?></td>
<td><?php echo e($item->city); ?></td>
<td>
<a href="<?php echo e(route('crud.edit',$item->id)); ?>" class="btn btn-success btn-sm">Edit Record</a>
<a href="<?php echo e(route('crud.show',$item->id)); ?>" class="btn btn-info btn-sm">View Record</a>
<a href="<?php echo e(route('crud.destroy',$item->id)); ?>" class="btn btn-danger btn-sm"
onclick="event.preventDefault();document.getElementById('delete-form').submit();">
Delete Record
</a>
<form action="<?php echo e(route('crud.destroy',$item->id)); ?>" method="POST" id="delete-form">
<?php echo csrf_field(); ?>
<?php echo method_field('DELETE'); ?>
</form>
</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
</div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('page.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\91959\Desktop\crud\resources\views/crud/index.blade.php ENDPATH**/ ?>