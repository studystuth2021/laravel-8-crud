

<?php $__env->startSection('title','View Page'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
<div class="col-md-12 col-lg-12 col-sm-12">
<table class="table table-striped table-bordered">
<tr>
<th>Name</th>
<td><?php echo e($post->name); ?></td>
</tr>
<tr>
<th>City Name</th>
<td><?php echo e($post->city); ?></td>
</tr>
<tr>
<th>Actions</th>
<td>
<a href="<?php echo e(route('crud.edit',$post->id)); ?>" class="btn btn-success btn-sm">Edit Record</a>
<a href="<?php echo e(route('crud.index')); ?>" class="btn btn-info btn-sm">Go Back</a>
<a href="<?php echo e(route('crud.destroy',$post->id)); ?>" class="btn btn-danger btn-sm"
onclick="event.preventDefault();document.getElementById('delete-form').submit();">
Delete Record
</a>
<form action="<?php echo e(route('crud.destroy',$post->id)); ?>" method="POST" id="delete-form">
<?php echo csrf_field(); ?>
<?php echo method_field('DELETE'); ?>
</form>
</td>
</tr>
</table>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('page.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\91959\Desktop\crud\resources\views/crud/show.blade.php ENDPATH**/ ?>